package com.mimacademy.pdf.work.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class TestConfiguration {
}
