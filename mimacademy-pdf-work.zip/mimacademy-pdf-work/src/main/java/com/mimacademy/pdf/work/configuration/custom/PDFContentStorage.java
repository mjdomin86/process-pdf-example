package com.mimacademy.pdf.work.configuration.custom;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

import org.flowable.common.engine.impl.util.IoUtil;
import org.flowable.content.api.ContentObject;
import org.flowable.content.api.ContentObjectStorageMetadata;
import org.springframework.beans.factory.annotation.Autowired;

import com.flowable.content.engine.impl.fs.SimpleFileSystemContentStorage;
import com.mimacademy.pdf.work.service.ElasticService;

public class PDFContentStorage extends SimpleFileSystemContentStorage {

    @Autowired
    private ElasticService elasticService;


    public PDFContentStorage(File contentFolderRoot) {
        super(contentFolderRoot);       
    }

    @Override
    public ContentObject createContentObject(InputStream contentStream, ContentObjectStorageMetadata metadata){
        ContentObject content = super.createContentObject(contentStream, metadata);

        String stringContent = null;

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(content.getContent()))) {
            stringContent = reader.lines().collect(Collectors.joining("\n"));
        } catch (Exception e) {

        }


        elasticService.indexPdfContent(metadata.getName(), stringContent);

        return content;
    }
}
