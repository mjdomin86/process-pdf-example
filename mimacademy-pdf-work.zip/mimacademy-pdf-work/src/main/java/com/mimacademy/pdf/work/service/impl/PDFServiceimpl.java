package com.mimacademy.pdf.work.service.impl;

import java.io.InputStream;
import java.util.List;

import org.flowable.content.api.ContentItem;
import org.flowable.content.api.ContentService;
import org.springframework.stereotype.Service;

import com.mimacademy.pdf.work.service.PDFService;

@Service
public class PDFServiceimpl implements PDFService{

    private final ContentService contentService;

    public PDFServiceimpl(ContentService contentService) {
        this.contentService = contentService;
    }

    @Override
    public InputStream getPDFContent(String name) {
        
        List<ContentItem> items = contentService.createContentItemQuery().name(name).list();

        ContentItem item = null;

        if (items != null && items.size() > 0)
            item = items.get(0);

        if (item != null )
            return contentService.getContentItemData(item.getId());
            
        return null;
    }
}
