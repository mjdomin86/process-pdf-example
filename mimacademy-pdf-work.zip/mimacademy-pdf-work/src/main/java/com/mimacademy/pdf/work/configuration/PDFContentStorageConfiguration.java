package com.mimacademy.pdf.work.configuration;

import java.io.File;

import org.flowable.content.api.ContentStorage;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.flowable.spring.boot.content.FlowableContentProperties;
import com.mimacademy.pdf.work.configuration.custom.PDFContentStorage;

@Configuration
public class PDFContentStorageConfiguration {

    @Bean
    public ContentStorage pdfContentStorage(FlowableContentProperties contentProperties) {
        String contentRootFolder;
        if(contentProperties.getStorage().getRootFolder() == null) {
            String userHome = System.getProperty("user.home");
            contentRootFolder = userHome + File.separator + "content";            
        } else {
            contentRootFolder = contentProperties.getStorage().getRootFolder();
        }

        File contentRootFile = new File(contentRootFolder);

        if(contentProperties.getStorage().getCreateRoot() && !contentRootFile.exists())
            contentRootFile.mkdirs();

        return new PDFContentStorage(contentRootFile);



    }

}
