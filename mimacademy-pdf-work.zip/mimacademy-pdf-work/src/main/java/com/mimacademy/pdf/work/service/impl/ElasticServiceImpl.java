package com.mimacademy.pdf.work.service.impl;

import com.mimacademy.pdf.work.service.ElasticService;
import reactor.netty.http.client.HttpClient;

import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;

import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import jakarta.json.Json;
import jakarta.json.JsonArray;
import jakarta.json.JsonObject;
import jakarta.json.JsonReader;
import reactor.core.publisher.Mono;

@Service
public class ElasticServiceImpl implements ElasticService {

    @Value("${elasticsearch.pdf-index}")
    private String pdfIndex;

    private final WebClient webClient;

    public ElasticServiceImpl(HttpClient httpClient,
            @Value("${elasticsearch.url:http://localhost:9200}") String elasticsearchUrl) {

        this.webClient = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .baseUrl(elasticsearchUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
                .build();

    }

    @Override
    public void initElastic() {
        createIngestPipeline();
        createIndexIfNotExists(pdfIndex);

    }

    private void createIngestPipeline() {

        JsonObject jsonObject = Json.createObjectBuilder()
                .add("processors", Json.createArrayBuilder()
                        .add(Json.createObjectBuilder()
                                .add("attachment", Json.createObjectBuilder()
                                        .add("field", "data")
                                        .add("properties", Json.createArrayBuilder()
                                                .add("content")
                                                .add("title")
                                                .add("identifier")
                                                .build())
                                        .add("remove_binary", true)
                                        .build())
                                .build())
                        .build())
                .build();

        webClient.put()
                .uri("/_ingest/pipeline/attachment")
                .body(BodyInserters.fromValue(jsonObject.toString()))
                .retrieve()
                .bodyToMono(String.class)
                .block();

    }

    private void createIndexIfNotExists(String indexName) {

        webClient.head() // Use HEAD request to check if index exists
                .uri("/" + indexName)
                .exchangeToMono(response -> {
                    if (response.statusCode().equals(HttpStatus.OK)) {
                        // Index exists, do nothing
                        return Mono.empty();
                    } else if (response.statusCode().equals(HttpStatus.NOT_FOUND)) {
                        // Index doesn't exist, create it
                        return webClient.put()
                                .uri("/" + indexName)
                                .retrieve()
                                .bodyToMono(String.class);
                    } else {
                        // Handle other error statuses if needed
                        return Mono.error(new RuntimeException("Unexpected response status: " + response.statusCode()));
                    }
                })
                .block(); // Block to make it synchronous if needed

    }

    public void indexPdfContent(String pdfFileName, String pdfText) {

        // 1. Encode PDF text to Base64
        String base64PdfText = Base64.getEncoder().encodeToString(pdfText.getBytes(StandardCharsets.UTF_8));

        // 2. Create a JSON object with Base64 encoded data
        Map<String, String> requestBody = Map.of("data", base64PdfText);

        // 3. Use WebClient to send a POST request
        webClient.post()
                .uri("/" + pdfIndex + "/_doc/" + pdfFileName + "?pipeline=attachment")
                .body(BodyInserters.fromValue(requestBody))
                .retrieve()
                .bodyToMono(String.class)
                .doOnSuccess(response -> System.out.println("Response: " + response))
                .doOnError(error -> System.err.println("Error: " + error.getMessage()))
                .block();
    }

    public String searchPdfContent(String content) {
        // 1. Create the JSON request body using JsonObject
        JsonObject requestBodyJson = Json.createObjectBuilder()
                .add("query", Json.createObjectBuilder()
                        .add("match", Json.createObjectBuilder()
                                .add("attachment.content", content)))
                .add("_source", Json.createArrayBuilder()
                        .add("_id")
                        .add("_score"))
                .build();

        // 2. Send the POST request
        String responseJson = webClient.post()
                .uri("/" + pdfIndex + "/_search")
                .body(BodyInserters.fromValue(requestBodyJson.toString()))
                .retrieve()
                .bodyToMono(String.class)
                .block();

        // 3. Parse and format the response
        return

        formatSearchResults(responseJson);
    }

    private String formatSearchResults(String responseJson) {
         try (JsonReader jsonReader = Json.createReader(new StringReader(responseJson))) {
            JsonObject root = jsonReader.readObject();
            JsonArray hitsArray = root.getJsonObject("hits").getJsonArray("hits");

            // Extract and format the required fields
            StringBuilder result = new StringBuilder("[");
            for (JsonObject hit : hitsArray.getValuesAs(JsonObject.class)) {
                String id = hit.getString("_id");
                double score = hit.getJsonNumber("_score").doubleValue();

                if (result.length() > 1) {
                    result.append(",");
                }

                result.append("{")
                      .append("\"_id\": \"").append(id).append("\",")
                      .append("\"_score\": ").append(score)
                      .append("}");
            }
            result.append("]");

            return result.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "Error processing search results";
        }
    }

}
