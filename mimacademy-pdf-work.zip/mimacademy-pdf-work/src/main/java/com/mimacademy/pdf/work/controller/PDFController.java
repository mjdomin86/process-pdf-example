package com.mimacademy.pdf.work.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.InputStream;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;

import com.mimacademy.pdf.work.service.PDFService;


@RestController
@RequestMapping("/pdf")
public class PDFController {

    private final PDFService pdfService;

    public PDFController(PDFService pdfService){
        this.pdfService = pdfService;
    }

    @GetMapping(value="/{pdfName:.+}/url",  produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<?> searchPdfContent(@PathVariable("pdfName") String pdfName) {  
        
        InputStream pdfFile = pdfService.getPDFContent(pdfName);

        InputStreamResource resource = new InputStreamResource(pdfFile);
               
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .body(resource);
    }

}
