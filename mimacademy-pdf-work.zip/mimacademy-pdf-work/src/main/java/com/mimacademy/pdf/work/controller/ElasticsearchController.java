package com.mimacademy.pdf.work.controller;

import com.mimacademy.pdf.work.service.ElasticService;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.IOException;

@RestController
@RequestMapping("/elasticsearch") // Base path for your Elasticsearch endpoints
public class ElasticsearchController {

    private final ElasticService elasticsearchService;

    public ElasticsearchController(ElasticService elasticsearchService) {
        this.elasticsearchService = elasticsearchService;
    }

    @PostMapping("/init")
    public ResponseEntity<String> initElastic() {
        elasticsearchService.initElastic();
        return ResponseEntity.ok("Elasticsearch initialized successfully");

    }

    @PostMapping(value = "/index", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> indexPdfContent(
            @RequestParam("pdfFile") MultipartFile pdfFile
    ) {
        if (pdfFile.isEmpty()) {
            return ResponseEntity.badRequest().body("Please select a PDF file to upload");
        }

        try {
            String pdfFileName = pdfFile.getOriginalFilename();
            String pdfText = extractTextFromPdf(pdfFile); // You'll need to implement this method

            elasticsearchService.indexPdfContent(pdfFileName, pdfText);
            return ResponseEntity.ok("PDF content indexed successfully");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error indexing PDF content: " + e.getMessage());
        }
    }

    // Helper method to extract text from PDF (you'll need to implement this)
    private String extractTextFromPdf(MultipartFile pdfFile) throws IOException {
        try (PDDocument document = Loader.loadPDF(pdfFile.getBytes())) {
            PDFTextStripper stripper = new PDFTextStripper();
            return stripper.getText(document);
        }
    }

    @GetMapping(value="/search", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> searchPdfContent(
            @RequestParam("content") String content
    ) {
       
        return ResponseEntity.ok(elasticsearchService.searchPdfContent(content));
    }
}