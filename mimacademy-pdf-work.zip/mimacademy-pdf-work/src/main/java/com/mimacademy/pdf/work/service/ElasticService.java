package com.mimacademy.pdf.work.service;


public interface ElasticService {

    void initElastic();

    void indexPdfContent(String pdfFileName, String pdfText);
    String searchPdfContent(String content);
}
