package com.mimacademy.pdf.work.service;

import java.io.InputStream;

public interface PDFService {

    InputStream getPDFContent(String name);
        
} 
